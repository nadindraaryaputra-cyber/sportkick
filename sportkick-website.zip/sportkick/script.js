const products = [
  {id:1,name:"Nike Air Max Red",category:"Running",price:1250000,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600",tag:"Best Seller"},
  {id:2,name:"Classic White Sneakers",category:"Sneakers",price:850000,image:"https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600",tag:"Popular"},
  {id:3,name:"Sport Running Shoes",category:"Running",price:950000,image:"https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=600",tag:"New"},
  {id:4,name:"Urban Street Sneakers",category:"Sneakers",price:1100000,image:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=600",tag:"Trending"},
  {id:5,name:"Casual Black Shoes",category:"Casual",price:750000,image:"https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?w=600",tag:"New"},
  {id:6,name:"Nike Sport Sneakers",category:"Sneakers",price:1350000,image:"https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=600",tag:"Best Seller"},
  {id:7,name:"Daily Running Shoes",category:"Running",price:890000,image:"https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=600",tag:"Popular"},
  {id:8,name:"Casual Lifestyle Shoes",category:"Casual",price:680000,image:"https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?w=600",tag:"Sale"}
];

const $ = id => document.getElementById(id);
const productGrid=$("productGrid"), searchInput=$("searchInput");
const categoryButtons=document.querySelectorAll(".category-btn");
const cartSidebar=$("cartSidebar"),cartOverlay=$("cartOverlay");
const cartItemsElement=$("cartItems"),cartCount=$("cartCount"),cartTotal=$("cartTotal");
let cart=[],selectedCategory="All",toastTimer;

function rupiah(value){
  return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(value);
}

function displayProducts(items){
  productGrid.innerHTML="";
  if(!items.length){productGrid.innerHTML='<p class="no-products">Produk tidak ditemukan.</p>';return;}
  items.forEach(product=>{
    const card=document.createElement("article");
    card.className="product-card";
    card.innerHTML=`
      <div class="product-image"><img src="${product.image}" alt="${product.name}" loading="lazy">
        <span class="product-tag">${product.tag}</span></div>
      <div class="product-info"><span class="product-category">${product.category}</span>
        <h3>${product.name}</h3>
        <div class="product-rating"><i class="fas fa-star"></i><i class="fas fa-star"></i>
          <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
          <span style="color:#777">(4.5)</span></div>
        <div class="product-bottom"><span class="product-price">${rupiah(product.price)}</span>
          <button class="add-cart" data-id="${product.id}" aria-label="Tambah ${product.name}"><i class="fas fa-plus"></i></button></div>
      </div>`;
    productGrid.appendChild(card);
  });
  productGrid.querySelectorAll(".add-cart").forEach(btn=>btn.addEventListener("click",()=>addToCart(Number(btn.dataset.id))));
}

function filterProducts(){
  const keyword=searchInput.value.trim().toLowerCase();
  displayProducts(products.filter(p=>(selectedCategory==="All"||p.category===selectedCategory)&&p.name.toLowerCase().includes(keyword)));
}

categoryButtons.forEach(btn=>btn.addEventListener("click",()=>{
  categoryButtons.forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");selectedCategory=btn.dataset.category;filterProducts();
}));
searchInput.addEventListener("input",filterProducts);

function addToCart(id){
  const product=products.find(p=>p.id===id);if(!product)return;
  const existing=cart.find(item=>item.id===id);
  existing?existing.quantity++:cart.push({...product,quantity:1});
  updateCart();showToast(product.name+" berhasil ditambahkan!");
}
function changeQuantity(id,amount){
  const item=cart.find(p=>p.id===id);if(!item)return;
  item.quantity+=amount;if(item.quantity<=0)cart=cart.filter(p=>p.id!==id);
  updateCart();
}
function removeFromCart(id){cart=cart.filter(p=>p.id!==id);updateCart();}

function updateCart(){
  cartItemsElement.innerHTML="";
  if(!cart.length)cartItemsElement.innerHTML='<p class="empty-cart">Keranjang masih kosong.</p>';
  let total=0,count=0;
  cart.forEach(item=>{
    total+=item.price*item.quantity;count+=item.quantity;
    const row=document.createElement("div");row.className="cart-item";
    row.innerHTML=`<img src="${item.image}" alt="${item.name}">
      <div class="cart-item-info"><h4>${item.name}</h4><p>${rupiah(item.price)}</p>
      <button class="remove-item" data-id="${item.id}">Hapus</button></div>
      <div class="quantity-controls"><button class="decrease" data-id="${item.id}" aria-label="Kurangi">-</button>
      <span>${item.quantity}</span><button class="increase" data-id="${item.id}" aria-label="Tambah">+</button></div>`;
    cartItemsElement.appendChild(row);
  });
  cartCount.textContent=count;cartTotal.textContent=rupiah(total);
  cartItemsElement.querySelectorAll(".increase").forEach(b=>b.addEventListener("click",()=>changeQuantity(Number(b.dataset.id),1)));
  cartItemsElement.querySelectorAll(".decrease").forEach(b=>b.addEventListener("click",()=>changeQuantity(Number(b.dataset.id),-1)));
  cartItemsElement.querySelectorAll(".remove-item").forEach(b=>b.addEventListener("click",()=>removeFromCart(Number(b.dataset.id))));
}
function openCart(){cartSidebar.classList.add("show");cartOverlay.classList.add("show");}
function closeCart(){cartSidebar.classList.remove("show");cartOverlay.classList.remove("show");}
$("cartButton").addEventListener("click",openCart);
$("closeCart").addEventListener("click",closeCart);
cartOverlay.addEventListener("click",closeCart);

function showToast(message){
  $("toast").textContent=message;$("toast").classList.add("show");
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2500);
}
$("checkoutButton").addEventListener("click",()=>{
  if(!cart.length){showToast("Keranjang belanja masih kosong!");return;}
  showToast("Checkout belum terhubung ke sistem pembayaran.");
});
$("newsletterForm").addEventListener("submit",event=>{
  event.preventDefault();showToast("Terima kasih sudah berlangganan!");event.target.reset();
});
$("menuToggle").addEventListener("click",()=>$("navLinks").classList.toggle("show"));
document.querySelectorAll(".nav-links a").forEach(link=>link.addEventListener("click",()=>$("navLinks").classList.remove("show")));
document.addEventListener("keydown",event=>{if(event.key==="Escape")closeCart();});

displayProducts(products);
updateCart();
